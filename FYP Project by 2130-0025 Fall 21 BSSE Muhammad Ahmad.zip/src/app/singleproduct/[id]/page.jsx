"use client";
import React, { useState, useContext } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { CartContext } from "@/context/CartProvider";
import { Toaster, toast } from "react-hot-toast";

const Page = ({ product }) => {
  const [activeImg, setActiveImg] = useState(product.image[0]);
  const [value, setValue] = useState(1);
  const [totalPrice, setTotalPrice] = useState(product.price);

  const { addToCart, cartItems } = useContext(CartContext);

  const updateTotalPrice = (quantity) => {
    setTotalPrice(product.price * quantity);
  };

  const handleAddToCart = () => {
    if (value <= product.stock) {
      addToCart(product, value);
      toast.success(`${product.title} added to cart!`);
    } else {
      toast.error("Not enough stock available");
    }
  };

  const settings = {
    dots: true,
    arrows: false,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 2,
    adaptiveHeight: true,
  };

  const cartItem = cartItems.find((item) => item._id === product._id) || { quantity: 0 };

  return (
    <div className="container mx-auto p-4">
      <Toaster />
      <div className="lg:flex md:flex mb-5 gap-4 globalShadow rounded-xl pb-2">
        {/* Product Image and Slider */}
        <div className="md:w-4/12">
          <div className="flex flex-col items-center mt-7 mb-5 mx-5">
            <div className="flex justify-center object-contain p-6 border w-80 border-gray-30 mb-5 shadow-inner shadow-orange-400">
              <img
                src={activeImg}
                alt="Active item"
                className="w-full h-72 max-w-md object-contain"
              />
            </div>
            <div className="w-full max-w-md p-2 shadow-inner shadow-orange-300">
              <Slider {...settings}>
                {product.image.map((img, i) => (
                  <div key={i} className="p-1 w-20 h-20">
                    <img
                      src={img}
                      className="w-16 h-20 p-3 border border-orange-300 rounded-md cursor-pointer"
                      alt={`Carousel item ${i}`}
                      onClick={() => setActiveImg(img)}
                    />
                  </div>
                ))}
              </Slider>
            </div>
          </div>
        </div>

        {/* Product Details */}
        <div className="mt-20 flex-1">
          <div className="mb-8 border border-orange-200 rounded-xl shadow-xl inline-block px-3 bg-orange-200 text-orange-500 ml-5">
            {product.category}
          </div>
          <h1 className="text-center mb-5 font-extrabold text-gray-700 text-3xl">{product.title}</h1>
          <hr />
          <div className="text-justify mr-5 indent-10 tracking-wide ml-2 mt-7 line-clamp-4">{product.desc}</div>
          <div className="md:flex justify-between mx-7 mt-20">
            <div className="mt-5 text-orange-400 text-xl">${product.price}</div>
            <div className="mt-5 text-gray-700 font-bold">Stock: {product.stock}</div>
          </div>

          {/* Quantity and Add to Cart */}
          <div className="flex items-center mt-10 ml-10">
            <div className="flex">
              <button
                className="border border-solid rounded-full w-7 h-7 text-gray-700 bg-gray-100 hover:bg-gray-200"
                onClick={() => {
                  if (value < product.stock) {
                    setValue(value + 1);
                    updateTotalPrice(value + 1);
                  }
                }}
              >
                +
              </button>
              <p className="mx-4 w-7 text-center">{value}</p>
              <button
                className="border border-solid rounded-full w-7 h-7 text-gray-700 bg-gray-100 hover:bg-gray-200"
                disabled={value === 1}
                onClick={() => {
                  if (value > 1) {
                    setValue(value - 1);
                    updateTotalPrice(value - 1);
                  }
                }}
              >
                -
              </button>
            </div>
          </div>
          <div className="mt-10 ml-10 flex gap-10">
            <button
              type="button"
              onClick={handleAddToCart}
              className="border px-6 sm:px-14 py-2 sm:py-4 font-bold text-white rounded-xl bg-orange-400 hover:bg-orange-500"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>

      {/* Product Description */}
      <div className="globalShadow rounded-xl p-5">
        <h2 className="text-2xl font-extrabold drop-shadow-lg mb-2">Description</h2>
        <hr />
        <div className="text-justify text-xs md:text-xl tracking-wide md:mt-7">{product.desc}</div>
      </div>
    </div>
  );
};

// Static product data for demo purposes
export const product = {
  _id: "1",
  title: "TechCo Galaxy X",
  desc: "The TechCo Galaxy X is a sleek and powerful smartphone featuring a 6.7-inch Super AMOLED display, a cutting-edge quad-camera system, and a long-lasting 5000mAh battery. Experience lightning-fast performance with the latest TechCo Processor and 5G connectivity.",
  price: 899,
  stock: 25,
  category: "Electronics",
  brand: "TechCo",
  ratings: 4.8,
  reviews: 320,
  specs: {
    display: "6.7-inch Super AMOLED, 120Hz",
    processor: "TechCo Processor X2",
    ram: "8GB",
    storage: "128GB",
    battery: "5000mAh",
    os: "TechCoOS 12",
    cameras: {
      main: "108MP + 12MP Ultra-Wide + 10MP Telephoto + 5MP Macro",
      front: "32MP",
    },
    connectivity: ["5G", "Wi-Fi 6", "Bluetooth 5.3", "NFC"],
  },
  warranty: "1 Year Manufacturer Warranty",
  image: [
    "https://img.freepik.com/free-vector/realistic-display-smartphone-with-different-apps_52683-30241.jpg",
  ],
};


export default () => <Page product={product} />;
