"use client";
import React, { useState } from "react";
import { Toaster, toast } from "react-hot-toast";
import Link from "next/link";
import { useRouter } from "next/navigation";

const Page = () => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const router = useRouter();

  const changeHandler = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({ ...prevFormData, [name]: value }));
  };

  const submitForm = (e) => {
    e.preventDefault();
    setLoading(true);

    const predefinedEmail = "user@example.com";
    const predefinedPassword = "password123";

    if (formData.email === predefinedEmail && formData.password === predefinedPassword) {
      toast.success("Login successful!");
      router.push("/admin"); // Redirect to dashboard after successful login
    } else {
      toast.error("Invalid email or password.");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Toaster />
      <form
        className="w-full max-w-md p-8 bg-white shadow-md rounded-md"
        onSubmit={submitForm}
      >
        <h2 className="text-center text-2xl font-bold mb-6">Login</h2>
        <div className="mb-4">
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Email
          </label>
          <input
            value={formData.email}
            onChange={changeHandler}
            type="email"
            name="email"
            id="email"
            placeholder="Enter your email"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
            required
          />
        </div>
        <div className="mb-6">
          <label
            htmlFor="password"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Password
          </label>
          <input
            value={formData.password}
            onChange={changeHandler}
            type="password"
            name="password"
            id="password"
            placeholder="Enter your password"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-orange-500 text-white py-2 rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500"
        >
          {loading ? "Processing..." : "Log In"}
        </button>
        <p className="mt-4 text-center text-sm text-gray-600">
          Don&apos;t Have an Account?&nbsp;
          <Link
            href="/register"
            className="text-orange-500 hover:underline"
          >
            Sign up
          </Link>
        </p>
      </form>
    </div>
  );
};

export default Page;
