import mongoose from "mongoose";

export default async function dbConnect(){
    try {
         if (mongoose.connection.readyState >=1) {
            return
         }

         await mongoose.connect("mongodb+srv://mazhar:mazhar123@savoy.5nro6.mongodb.net/")
    } catch (error) {
        console.log(error)
        return false
    }
}





