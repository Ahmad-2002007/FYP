/** @type {import('next').NextConfig} */
const nextConfig = {
  env: {
    CLOUDINARY_URL: "576929442598814:OCx2qpgNlOB_WEUIRDmGepVlAwg@dap6pjdcs",
    NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME: "dap6pjdcs",
    NEXT_PUBLIC_CLOUDINARY_API_KEY: "576929442598814",
    NEXT_PUBLIC_CLOUDINARY_API_SECRET: "OCx2qpgNlOB_WEUIRDmGepVlAwg",
    JWT_SECRET: "e-comer12323"
  },
};

export default nextConfig;
